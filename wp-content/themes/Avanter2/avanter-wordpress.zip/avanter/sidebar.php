<?php
/**
 * The Sidebar containing the main widget areas.
 *
 * @package progression
 * @since progression 1.0
 */
?>

<div id="sidebar">
	<?php if ( ! dynamic_sidebar( 'sidebar-1' ) ) : ?>
	<?php endif; // end sidebar widget area ?>
</div><!-- close #sidebar -->
